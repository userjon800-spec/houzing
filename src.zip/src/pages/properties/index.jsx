
import Properties from '../../components/properties'


const PropertiesPage = ()=> <Properties />

export default PropertiesPage