export const reducer = (state, { type, action }) => {
  switch (type) {
    case "plus":
      return state;
    default:
      return state;
  }
};
